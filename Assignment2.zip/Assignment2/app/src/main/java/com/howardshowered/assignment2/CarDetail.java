package com.howardshowered.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class shows a layout fragment of the car details
 */
public class CarDetail extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_detail);
        //creates intent
        Intent intent = getIntent();
        String itemPos = intent.getStringExtra("itemPos"); //gets the car selected from recyleview
        //creates carFragement object with new instance to pass car position
        FragmentCarDetail carFragment = FragmentCarDetail.newInstance(Integer.parseInt(itemPos));
        getSupportFragmentManager().beginTransaction().add(R.id.car_frament, carFragment).commit();

    }



}
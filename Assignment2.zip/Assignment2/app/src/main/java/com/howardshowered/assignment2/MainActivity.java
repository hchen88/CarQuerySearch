package com.howardshowered.assignment2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private String TAG = MainActivity.class.getSimpleName();
    private Spinner makeSpinner;
    ArrayAdapter<String> adapter;
    private Spinner modelSpinner;
    private static RecyclerView  carRecyclerView;
    private WordListAdapter carAdapter;
    private String  vehicle_make_id  = "10";
    private String vehicle_model_id = "20";
    private static String make;
    private static String model;
    private String zipCode = "92603";
    HashMap<String, String> carsHashMap = new HashMap<>();
    ArrayList<HashMap<String, String>> carsList;
    ArrayList<String> carsStringList;
    ArrayList<String> carModelStringList;
    ArrayList<String> carsStringList2 = new ArrayList<>();
    ArrayList<HashMap<String, String>> carsModelList;
    private static ArrayList<String> carsStringIdList;


    // URL to get contacts JSON
    private static String makeUrl = "https://thawing-beach-68207.herokuapp.com/carmakes";

    private static String modelUrl = "https://thawing-beach-68207.herokuapp.com/carmodelmakes/";

    // vehicleId/ vehicle_make_id;
    private static String makeModelUrl = "https://thawing-beach-68207.herokuapp.com/cars/10/20/92603";

    public static ArrayList<String> getcarsStringIdList(){
        return carsStringIdList;
    }

    public static RecyclerView getReyclerView() {
        return carRecyclerView;
    }

    public static String getVehicleMakeModel(){
        String vehicleMakeModel = make + " - " + model;

        return vehicleMakeModel;
    }
    //"https://thawing-beach-68207.herokuapp.com/cars/10/20/92603"
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vehicle_make_id = "10"; //default
        vehicle_model_id = "20";// default
        carModelStringList = new ArrayList<>();
        carsList = new ArrayList<>();
        carsStringList = new ArrayList<>();
        carsStringList2 = new ArrayList<>();
        carsStringIdList = new ArrayList<>();
        String idNumber2 = "3484";

        makeSpinner = (Spinner) findViewById(R.id.spinnerMake);
        modelSpinner = (Spinner) findViewById(R.id.spinnerModel);
        carRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        new getVehiclesMakes().execute();

        makeSpinner.setOnItemSelectedListener(new  AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItem = parentView.getItemAtPosition(position).toString();

                //idNumber = carsHashMap.get(selectedItem);
                for(int i =0; i< carsList.size(); i++ ) {
                    if(carsList.get(i).get("vehicle_make").equals(selectedItem)){
                        vehicle_make_id = carsList.get(i).get("id");
                        make = selectedItem;
                    }
                }
                modelUrl = "https://thawing-beach-68207.herokuapp.com/carmodelmakes/" + vehicle_make_id;
                new getVehiclesModels().execute();
                }


            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


        modelSpinner.setOnItemSelectedListener(new  AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                //selected item is the model names
                //need to get the vehicle_make id
                String selectedCar = parentView.getItemAtPosition(position).toString();

                for(int i = 0; i < carsModelList.size(); i++) {
                    if(carsModelList.get(i).get("model").equals(selectedCar)){
                        vehicle_model_id = carsModelList.get(i).get("id");
                        makeModelUrl = "https://thawing-beach-68207.herokuapp.com/cars/" + vehicle_make_id + "/" + vehicle_model_id + "/"
                                + zipCode;
                        model = selectedCar;
                        new getVehicles().execute();
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                new getVehicles().execute();
            }

        });

        //creates an adapter and supplys the data to be displayed
        carAdapter = new WordListAdapter(this, carsStringList2);
        //sets adapter with the recycler view in xml file
        carRecyclerView.setAdapter(carAdapter);
        //Give the recycler view a default layout manager.
        carRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

    }

    /**
     * Async task class to get json by making HTTP call
     * gets Vehicle Makes json
     */
    private class getVehiclesMakes extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
//            pDialog = new ProgressDialog(MainActivity.this);
//            pDialog.setMessage("Please wait...");
//            pDialog.setCancelable(false);
//            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();

            carsList = new ArrayList<>();
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(makeUrl);

            jsonStr = "{\"cars_list\":" + jsonStr + "}";
            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    // Getting JSON Array node
                    JSONArray makes = jsonObj.getJSONArray("cars_list");

                    // looping through All Contacts
                    for (int i = 0; i < makes.length(); i++) {
                        JSONObject c = makes.getJSONObject(i);
                        carsHashMap = new HashMap<>();
                        String id = c.getString("id");
                        String vehicleMake = c.getString("vehicle_make");
                        carsHashMap.put("vehicle_make", vehicleMake);
                        carsHashMap.put("id", id);
                        carsStringList.add(vehicleMake);
                        carsList.add(carsHashMap);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
//            if (pDialog.isShowing())
//                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */
            ArrayAdapter<String> car_make_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, carsStringList);
            car_make_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            makeSpinner.setAdapter(car_make_adapter);

        }

    }

        /**
         * Async task class for vehicleModels Json Spinner
         */
        private class getVehiclesModels extends AsyncTask<Void, Void, Void> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected Void doInBackground(Void... arg0) {
                HttpHandler sh = new HttpHandler();
                carsModelList = new ArrayList<>();
                // Making a request to url and getting response
                String jsonStr = sh.makeServiceCall(modelUrl);

                jsonStr = "{\"model_list\":" + jsonStr + "}";
                Log.e(TAG, "Response from url: " + jsonStr);

                if (jsonStr != null) {
                    try {
                        JSONObject jsonObj = new JSONObject(jsonStr);
                        carModelStringList = new ArrayList<>();

                        // Getting JSON Array node
                        JSONArray models = jsonObj.getJSONArray("model_list");

                        // looping through All Contacts
                        for (int i = 0; i < models.length(); i++) {
                            JSONObject m = models.getJSONObject(i);
                            HashMap<String, String> carsModelHashMap = new HashMap<>();
                            String id = m.getString("id");
                            String vehicleModel = m.getString("model");
                            String vehicleMakeId = m.getString("vehicle_make_id");

                            carsModelHashMap.put("id", id);
                            carsModelHashMap.put("model", vehicleModel);
                            carsModelHashMap.put("vehicle_make_id", vehicleMakeId);
                            carsModelHashMap.put("index", Integer.toString(i));
                            carModelStringList.add(vehicleModel);
                            carsModelList.add(carsModelHashMap);
                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(),
                                        "Json parsing error: " + e.getMessage(),
                                        Toast.LENGTH_LONG)
                                        .show();
                            }
                        });

                    }
                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat for possible errors!",
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });
                }
                return null;
            }
            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                // Dismiss the progress dialog
//            if (pDialog.isShowing())
//                pDialog.dismiss();
                /**
                 * Updating parsed JSON data into Spinner
                 * */
                ArrayAdapter<String> car_model_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, carModelStringList);
                car_model_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                modelSpinner.setAdapter(car_model_adapter);
            }

        }

        //need to make another AsyncTask for RecycleView
    /**
     * Async task class for vehicles Json Recycler View
     */
    private class getVehicles extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(makeModelUrl);

            //jsonStr = "{\"model_list\":" + jsonStr + "}";
            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    JSONArray models = jsonObj.getJSONArray("lists");
                    carsStringList2 = new ArrayList<>();
                    carsStringIdList = new ArrayList<>();
                    // looping through All Contacts
                    for (int i = 0; i < models.length(); i++) {
                        JSONObject m = models.getJSONObject(i);
                        HashMap<String, String> carsHashMap = new HashMap<>();
                        String id = m.getString("id");
                        String make = m.getString("vehicle_make");
                        String color = m.getString("color");
                        String listItemTitle = make + " " + Integer.toString(i+1) + " (" + color + ") id: "  + id;
                        //String listItemTitle = make + " " + Integer.toString(i+1);
                        carsHashMap.put("make", make);
                        carsHashMap.put("id", id);
                        carsStringList2.add(listItemTitle);
                        carsStringIdList.add(id);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            /**
             * NEEDS WORK
             * Updating parsed JSON data into ReyclerView
             * */
            //        creates an adapter and supplys the data to be displayed
            carAdapter = new WordListAdapter(MainActivity.this, carsStringList2);
            //       sets adapter with the recycler view in xml file
            carRecyclerView.setAdapter(carAdapter);
            //     Give the recycler view a default layout manager.
            carRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false));

        }

    }

}









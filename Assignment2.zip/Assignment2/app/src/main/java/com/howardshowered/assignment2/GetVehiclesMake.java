package com.howardshowered.assignment2;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetVehiclesMake extends AsyncTask<Void, Void, Void> {

    private String makeURL = "https://thawing-beach-68207.herokuapp.com/carmakes";
    ArrayList<String> makeArrayList = new ArrayList();
    private String TAG = GetVehiclesMake.class.getSimpleName();


    @Override
    protected Void doInBackground(Void... voids) {
        //logic of the data
        HttpHandler sh = new HttpHandler();
        String jsonStr = sh.makeServiceCall(makeURL);

        jsonStr = "(\"cars_list\":" + jsonStr + "}";
        Log.e(TAG, "responses from url:" + jsonStr );

        if( jsonStr != null) {

            try {

                JSONObject jsonObj = new JSONObject(jsonStr);
                JSONArray makes = jsonObj.getJSONArray("contacts");

                for (int i = 0; i < makes.length(); i++) {
                    JSONObject c = makes.getJSONObject(i);

                    String id = c.getString("id");
                    String vehicleMake = c.getString("vehicle_make");

                    JSONObject



                }

            } catch (final JSONException e) {
                e.printStackTrace();
            }


        }


        return null;
    }
}

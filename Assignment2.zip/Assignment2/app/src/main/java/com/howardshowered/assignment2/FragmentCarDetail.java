package com.howardshowered.assignment2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;


/**
 *
 * A Fragment sub class that displays the car details based on car selected
 * from reyclerview
 *
 */
public class FragmentCarDetail extends Fragment {
    //default url for last JSON request
    private String lastURL = "https://thawing-beach-68207.herokuapp.com/cars/3484";
    private String TAG = MainActivity.class.getSimpleName(); //Tag for logs
    private static String imgUrl;  //the image url string
    public static TextView makeModelView; //textview for make/model
    public static TextView shortDescriptionView; // textview for short description of car
    public static TextView priceView; // textview for price
    public static ImageView imageView; // image view for car
    public static TextView lastUpdateView; //last updated textview
    private static HashMap<String, String> carsHashMap = new HashMap<>(); //carsHashmap
    private  ArrayList<HashMap<String, String>> carsList; // list of cars with hashmaps
    private static int position; // position selected

    public FragmentCarDetail() {
        // Required empty public constructor
    }


    public static FragmentCarDetail newInstance(int pos) {
        position = pos;  // sets car postion
        FragmentCarDetail fragment = new FragmentCarDetail(); // creeats new fragment object
        Bundle args = new Bundle(); // new bundle obj
        args.putInt(Integer.toString(WordListAdapter.itemPosition), pos); //gets position of fragment
        fragment.setArguments(args);  // sets argument for fragment
        return fragment; // returns fragment to activity
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    //this method is where most of the work is done to inflate the layout for this fragment
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View car_view = inflater.inflate(R.layout.fragment_car_detail, container, false);
        //inflate all Views
        lastUpdateView = (TextView) car_view.findViewById(R.id.txt_lastUpdate);
        makeModelView = (TextView) car_view.findViewById(R.id.txt_makeModel);
        shortDescriptionView = (TextView) car_view.findViewById(R.id.txt_description);
        priceView = (TextView) car_view.findViewById(R.id.txt_price);
        imageView = (ImageView) car_view.findViewById(R.id.imageView);

        //gets the idNumber of car from the stringlist built in Json
        String idNumber = MainActivity.getcarsStringIdList().get(position);
        lastURL = "https://thawing-beach-68207.herokuapp.com/cars/" + idNumber;

        new getVehicleInformation().execute(); // executes Async task to gather up vehicle information

        return car_view; //returns the view.
    }

    private class getVehicleInformation extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            //creates new HttpHandler
            HttpHandler sh = new HttpHandler();
            carsList = new ArrayList<>(); //creates new carList
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(lastURL); //makes service call
            jsonStr = "{\"cars_list\":" + jsonStr + "}"; //concantnates cars list to jsonString

            Log.e(TAG, "Response from url: " + jsonStr); //sends a log for troubleshooting purposes

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    // Getting JSON Array node
                    JSONArray models = jsonObj.getJSONArray("cars_list");

                    // looping through All Contacts
                    for (int i = 0; i < models.length(); i++) {
                        JSONObject m = models.getJSONObject(i);
                        carsHashMap = new HashMap<>();
                        String imageUrl = m.getString("image_url");
                        String makeId = m.getString("vehicle_make_id");
                        String modelId = m.getString("vehicle_model_id");
                        String lastUpdated = m.getString("updated_at");
                        String shortDescription = m.getString("veh_description");
                        String price = m.getString("price");

                        carsHashMap.put("make_id", makeId);
                        carsHashMap.put("imageUrl", imageUrl);
                        carsHashMap.put("modelId", modelId);
                        carsHashMap.put("lastUpdated", lastUpdated);
                        carsHashMap.put("shortDescription", shortDescription);

                        carsHashMap.put("price", price);
                        carsList.add(carsHashMap);
                    }
                } catch (final JSONException e) { // exception handling
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else { //unable to get jsons
                Log.e(TAG, "Couldn't get json from server.");
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getActivity(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // sets texts for all views
            shortDescriptionView.setText(carsHashMap.get("shortDescription"));
            makeModelView.setText(MainActivity.getVehicleMakeModel());
            lastUpdateView.setText("Last Update: " + carsHashMap.get("lastUpdated"));
            priceView.setText("$" + carsHashMap.get("price"));
            imgUrl = carsHashMap.get("imageUrl");
            new DownloadImageTask(imageView) // calls Download image Async task
                    .execute(imgUrl);
        }
    }

    // this class downloads image from url
    // Source -https://stackoverflow.com/questions/2471935/how-to-load-an-imageview-by-url-in-android
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in); //decodes Stream of bitmap
            } catch (Exception e) { //handles exceptions
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

}

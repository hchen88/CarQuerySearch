package com.howardshowered.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class CarDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_car_detail);

        if(savedInstanceState == null) {
            //Get the selected car postion from the intent extra
            String selectedCar = getIntent().getStringExtra("itemPos");
            CarDetailFragment fragment = CarDetailFragment.newInstance(selectedCar);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.cars_detail_container, fragment)
                    .commit();
        }
    }


}
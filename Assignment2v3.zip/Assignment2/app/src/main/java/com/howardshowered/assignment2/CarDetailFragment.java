package com.howardshowered.assignment2;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class CarDetailFragment extends Fragment {

    private String lastURL = "https://thawing-beach-68207.herokuapp.com/cars/3484";
    private String TAG = MainActivity.class.getSimpleName();
    private static String imgUrl;
    static ArrayList<HashMap<String, String>> carsList;
    private TextView makeModelView;
    private TextView shortDescriptionView;
    private TextView priceView;
    private ImageView imageView;
    private TextView lastUpdateView;
    private static HashMap<String, String> carsHashMap = new HashMap<>();


    public CarDetailFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //not sure what to put


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_car_detail, container, false);

        lastUpdateView = (TextView) rootView.findViewById(R.id.txt_lastUpdate);
        makeModelView = (TextView) rootView.findViewById(R.id.txt_makeModel);
        shortDescriptionView = (TextView) rootView.findViewById(R.id.txt_description);
        priceView = (TextView) rootView.findViewById(R.id.txt_price);
        imageView = (ImageView) rootView.findViewById(R.id.imageView);

        String idNumber = MainActivity.getcarsStringIdList().get();
        //????
        lastURL = "https://thawing-beach-68207.herokuapp.com/cars/" + idNumber;

        new CarDetailFragment.getVehicleInformation().execute();

        return rootView;
    }

    public static CarDetailFragment newInstance(int selectedCar) {
        CarDetailFragment fragment = new CarDetailFragment();
        //set bundle args for the fragment
        Bundle arguments = new Bundle();
        arguments.putInt("carPos", selectedCar);
        fragment.setArguments(arguments);
        return fragment;
    }


    /**
     * Async task class for vehicles Json Recycler View
     */
    private class getVehicleInformation extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            carsList = new ArrayList<>();
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(lastURL);
            jsonStr = "{\"cars_list\":" + jsonStr + "}";

            //jsonStr = "{\"model_list\":" + jsonStr + "}";
            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    // Getting JSON Array node
                    JSONArray models = jsonObj.getJSONArray("cars_list");

                    // looping through All Contacts
                    for (int i = 0; i < models.length(); i++) {
                        JSONObject m = models.getJSONObject(i);
                        carsHashMap = new HashMap<>();
                        String imageUrl = m.getString("image_url");
                        String makeId = m.getString("vehicle_make_id");
                        String modelId = m.getString("vehicle_model_id");
                        String lastUpdated = m.getString("updated_at");
                        String shortDescription = m.getString("veh_description");
                        String price = m.getString("price");

                        carsHashMap.put("make_id", makeId);
                        carsHashMap.put("imageUrl", imageUrl);
                        carsHashMap.put("modelId", modelId);
                        carsHashMap.put("lastUpdated", lastUpdated);
                        carsHashMap.put("shortDescription", shortDescription);

                        carsHashMap.put("price", price);
                        carsList.add(carsHashMap);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getActivity().getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            shortDescriptionView.setText(carsHashMap.get("shortDescription"));
            makeModelView.setText(MainActivity.getVehicleMakeModel());
            lastUpdateView.setText("Last Update: " + carsHashMap.get("lastUpdated"));
            priceView.setText("$" + carsHashMap.get("price"));
            imgUrl = carsHashMap.get("imageUrl");
            new CarDetailFragment.DownloadImageTask(imageView)
                    .execute(imgUrl);
        }
    }

    // Source -https://stackoverflow.com/questions/2471935/how-to-load-an-imageview-by-url-in-android
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }



}

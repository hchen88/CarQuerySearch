package com.example.quizztaker;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * An activity which receive user's input for username and password
 * and check if this account is already register; if not, then display
 * a toast message saying that the account is invalid.  The user can play
 * as guest by clicking on "Play as guest", it will take the user to main
 * menu page; or create an account by clicking on "Sign up", it will
 * take the user to sign up page
 */
public class LogInActivity extends AppCompatActivity
{
    //declare objects for controls
    private EditText username_edittext;
    private EditText password_edittext;
    private TextView sign_up_text;
    private TextView guest_text;
    private Button login_button;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //create control objects
        username_edittext = (EditText) findViewById(R.id.username_edit);
        password_edittext = (EditText) findViewById(R.id.password_edit);
        sign_up_text = (TextView) findViewById(R.id.signup_text);
        guest_text = (TextView) findViewById(R.id.guest_player_text);
        login_button = (Button) findViewById(R.id.login_button);

        //hide action bar for this activity
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //this method is used to listen login event
        login_button.setOnClickListener(new View.OnClickListener()
        {
            /**
             * If user clicks on login button then we have to check
             * for valid account.  If account is valid then we go to
             * main menu page, else we send an error toast message
             *
             * @param v
             */
            public void onClick(View v)
            {
                String username = username_edittext.getText().toString();
                String password = password_edittext.getText().toString();

                //check if account is valid
                if(isValidAccount(username, password))
                {
                    //send an intent to MainMenuActivity
                    Intent intent = new Intent(getApplication(), MainMenuActivity.class);
                    startActivity(intent);
                }
                else
                {
                    //send a toast message on screen
                    Toast.makeText(getApplicationContext(), "Invalid Account!", Toast.LENGTH_SHORT).show();
                    //clear the password field
                    password_edittext.getText().clear();
                }
            }
        });
    }

    /**
     * This function is used to check if the account is already
     * registerd or not
     *
     * @param username account's username
     * @param password account's password
     *
     * @return return true if account is already registered, else
     * return false
     */
    public boolean isValidAccount(String username, String password)
    {

    }
}

package com.example.quizztaker;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ChangeNameActivity extends AppCompatActivity {

    private TextView settings_title_text;
    private Button change_name_button;
    private Button change_password_button;
    private Button help_button;
    private Button log_out_button;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_name);

        //creates control objects
        settings_title_text = (TextView) findViewById(R.id.settings_title_text);
        change_name_button = (Button) findViewById(R.id.change_name_button);
        change_password_button = (Button) findViewById(R.id.change_password_button);
        help_button = (Button) findViewById(R.id.help_button);
        log_out_button = (Button) findViewById(R.id.log_out_button);


        //hide action bar for this activity
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        change_name_button.setOnClickListener(new View.OnClickListener()
        {
            /**
             * change_name_button clicks sends user to ChangeNameActivity
             *
             * @param v
             */
            public void onClick(View v)
            {
                Intent intent = new Intent(getApplication(), ChangeNameActivity.class);
                startActivity(intent);
            }
        });


    }
}

package com.example.quizztaker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * A class which uses SQLite to create database for quiz taker game
 */
public class Database extends SQLiteOpenHelper
{
    //declare and initialize variables for database tables and columns
    private static final String DATABASE_NAME = "QuizTaker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_ACCOUNT = "accounts";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_EMAIL = "email";
    private static final String COL_INGAMENAME = "ingamename";

    private static final String TABLE_QUESTION = "questions";
    private static final String TABLE_LEADERBOARD = "leaderboards";

    /**
     * Create database through constructor
     */
    public Database(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Create tables in database
     */
    public void onCreate(SQLiteDatabase db)
    {
        //create accounts table
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_ACCOUNT + "(" + COL_INGAMENAME + " TEXT," + COL_USERNAME + " TEXT," + COL_PASSWORD + " TEXT," + COL_EMAIL + " TEXT);");
    }

    /**
     * Drop all the tables and recreate them to make any changes
     */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCOUNT);

        //call onCreate method to recreate tables
        onCreate(db);
    }

    /**
     *This method is used to add new account to database
     */
    public void addAccount(String in_game_name, String username, String password, String email)
    {
        //get an database object that is used to write data to the database
        SQLiteDatabase db = this.getWritableDatabase();

        //adding new account in accounts table
        ContentValues values = new ContentValues();
    }
}
